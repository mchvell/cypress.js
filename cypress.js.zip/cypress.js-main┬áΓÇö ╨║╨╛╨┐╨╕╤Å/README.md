### Как запустить?

1. Установить node.js: https://nodejs.org/en/download/
2. Скачать проект из github и открыть в IDE (например, sublime): 
3. Запустить команду в гитбаше (в папке cypress): `npm install`
4. Установить cypress (в гитбаше): `npm install cypress --save-dev`
6. Запускать автотесты командой `npm run test` 
7. Все новые тесты нужно писать в папке /integration
